#include <REGX52.H>
#include "Delay.h"
#include "UART.h"


void main()
{	
	UART_Init();
	
	while(1)
	{
		
	}	
}	
//
void UART_Rountine()  interrupt 4
{    //判断是谁中断
    if(RI==1)
	{
		P2=~SBUF;
		UART_SendByte(SBUF);
		RI=0;
	}
	
}




